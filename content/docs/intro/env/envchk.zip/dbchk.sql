CREATE DATABASE IF NOT EXISTS dbe2;
use dbe2;

drop table if exists table1;
create table table1 (
  id int primary key auto_increment,
  fld1 varchar(10),
  fld2 date,
  fld3 int
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
insert into table1(fld1, fld2, fld3) values
  ('value1', '2001-01-01', 100),
  ('value2', NULL, 150),
  (NULL, '2001-02-01', NULL);

drop table if exists 家計簿;
CREATE TABLE `家計簿` (
  `日付` date NOT NULL,
  `費目` varchar(10) NOT NULL,
  `メモ` varchar(30) NOT NULL,
  `入金額` int(11) NOT NULL,
  `出金額` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

drop table if exists 家計簿追加;
CREATE TABLE `家計簿追加` (
  `日付` date NOT NULL,
  `費目` varchar(10) COLLATE utf8_bin NOT NULL,
  `メモ` varchar(30) COLLATE utf8_bin NOT NULL,
  `入金額` int(11) NOT NULL,
  `出金額` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS 試験成績;
CREATE TABLE `試験成績` (
  `学籍番号` int(11) NOT NULL,
  `氏名` varchar(10) NOT NULL,
  `クラス` char(1) NOT NULL,
  `英語1` int(11) DEFAULT NULL,
  `心理学` int(11) DEFAULT NULL,
  `法学` int(11) DEFAULT NULL,
  `総合成績` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

drop table if exists 試験2;
drop table if exists 学生2;

create table 学生2 (
  `学籍番号` int(11) primary key,
  `氏名` varchar(10) NOT NULL,
  `クラス` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

create table 試験2 (
  学籍番号 int(11) NOT NULL,
  科目名 varchar(10) not null,
  得点 int(11) not null,
  foreign key (学籍番号) references 学生2(学籍番号)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

drop table if exists 住民;
create table 住民 (
  ID char(7) primary key,
  氏名 varchar(10) not null,
  性別 char(1) not null,
  誕生日 date not null,
  父 char(7),
  母 char(7),
  配偶者 char(7)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


DROP TABLE IF EXISTS 注文履歴47;
CREATE TABLE 注文履歴47 (
  日付 DATE,
  注文番号 INTEGER,
  注文枝番 INTEGER,
  商品名 VARCHAR(50),
  分類 CHAR(1),
  サイズ CHAR(1),
  単価 INTEGER,
  数量 INTEGER,
  注文金額 INTEGER
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2013-01-01',101,1,'ブレンドコーヒー',1,'S',210,1,210 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2013-01-01',101,2,'サンドイッチA',2,'X',360,1,360 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2013-01-05',105,1,'カフェラテ',1,'M',380,2,760 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2012-01-05',106,1,'抹茶ラテ',1,'S',370,1,370 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2012-01-05',110,1,'アイスコーヒー',1,'M',280,3,840 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2012-01-06',112,1,'サンドイッチB',2,'X',350,1,350 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2012-01-06',112,2,'ベーグルサンド',2,'X',420,2,840 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2012-01-06',112,3,'ブレンドコーヒー',1,'S',210,1,210 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2012-01-03',103,1,'トートバッグ',3,'X',1500,3,4500 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2012-01-03',104,1,'ニューイヤービーンズ',3,'X',650,2,1300 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2012-01-08',120,1,'タンブラー',3,'X',800,1,800 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2012-01-08',121,1,'マグカップ',3,'X',900,2,1800 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2013-01-07',132,1,'カフェラテ',1,'M',380,1,380 );
INSERT INTO 注文履歴47 ( 日付,注文番号,注文枝番,商品名,分類,サイズ,単価,数量,注文金額 ) VALUES ( '2013-01-07',132,2,'サンドイッチB',2,'X',350,1,350 );


--
-- テーブルのデータのダンプ `家計簿`
--

INSERT INTO `家計簿` (`日付`, `費目`, `メモ`, `入金額`, `出金額`) VALUES
('2013-02-03', '食費', 'コーヒーを購入', 0, 380),
('2013-02-10', '給料', '1月の給料', 280000, 0),
('2013-02-11', '教養娯楽費', '書籍を購入', 0, 2800),
('2013-02-14', '交際費', '同期会の会費', 0, 5000),
('2013-02-18', '水道光熱費', '1月の電気代', 0, 7560);

INSERT INTO 家計簿追加 VALUES
('2017-09-15', '食費', 'コーヒーを購入', 0, 390),
('2017-09-15', '給料', '9月の給料', 283000, 0),
('2017-09-17', '交際費', '町内会費', 0, 900),
('2017-09-17', '医療費', '歯科検診', 0, 2300),
('2017-09-19', '水道光熱費', '9月の電気代', 0, 6350),
('2017-09-20', '食費', '米を購入', 0, 3300);

--
-- Indexes for dumped tables
--

INSERT INTO `試験成績` (`学籍番号`, `氏名`, `クラス`, `英語1`, `心理学`, `法学`) VALUES
(16001, '金谷 麻巳子', 'A', 46, 91, 72),
(16002, '矢島 与四郎', 'A', 72, NULL, 40),
(16003, '梶原 芳彦', 'A', 89, 50, 73),
(16004, '上原 薫', 'A', 32, 66, 33),
(16005, '安藤 愛子', 'B', 44, 31, 36),
(16006, '浅野 清美', 'B', 64, 90, 48),
(16007, '宮野 葉子', 'B', 71, 83, 56),
(16008, '松浦 美玖', 'C', 62, 93, NULL),
(16009, '奥田 陽向', 'C', 51, 42, NULL),
(16010, '大河原 弘一', 'C', 79, 88, 54);

insert into 学生2 values
(16001, '金谷 麻巳子', 'A'),
(16002, '矢島 与四郎', 'A'),
(16003, '梶原 芳彦', 'A'),
(16004, '上原 薫', 'A'),
(16005, '安藤 愛子', 'B'),
(16006, '浅野 清美', 'B'),
(16007, '宮野 葉子', 'B'),
(16008, '松浦 美玖', 'C'),
(16009, '奥田 陽向', 'C'),
(16010, '大河原 弘一', 'C'),
(16011, '道園 乗政', 'B');

insert into 試験2 values
(16001, '英語1', 46),
(16001, '心理学', 91),
(16001, '法学', 72),
(16002, '英語1', 72),
(16002, '法学', 40),
(16003, '英語1', 89),
(16003, '心理学', 50),
(16003, '法学', 73),
(16004, '英語1', 32),
(16004, '心理学', 66),
(16004, '法学', 33),
(16005, '英語1', 44),
(16005, '心理学', 31),
(16005, '法学', 36),
(16006, '英語1', 64),
(16006, '心理学', 90),
(16006, '法学', 48),
(16007, '英語1', 71),
(16007, '心理学', 83),
(16007, '法学', 56),
(16008, '英語1', 62),
(16008, '心理学', 93),
(16009, '英語1', 51),
(16009, '心理学', 42),
(16010, '英語1', 79),
(16010, '心理学', 88),
(16010, '法学', 54);

--
-- Indexes for dumped tables
--

ALTER TABLE `試験成績`
  ADD PRIMARY KEY (`学籍番号`);

drop table if exists 売上1;
drop table if exists 商品1;
CREATE TABLE 商品1 (
  商品番号 char(4) primary key,
  商品名 varchar(40) not null,
  価格 int(11),
  発売日 date
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
create table 売上1 (
  連番 int(11) primary key,
  日付 date,
  販売商品 char(4),
  数量 int(11),
  顧客 varchar(20),
  FOREIGN KEY (販売商品) REFERENCES 商品1(商品番号)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

insert into 商品1 values
  ('XC01', 'セロハンテープ', 120, '2014-10-01'),
  ('DD28', 'A5ノート', 95, '2010-05-18'),
  ('DD31', 'くろぐろ鉛筆', 30, '2015-12-03'),
  ('FC96', '北方シャープペン', 300, '2013-02-03'),
  ('EP44', 'ポストイット', 250, '2015-11-10');

insert into 売上1 values
  (1, '2016-11-01', 'XC01',  2, '赤間一郎'),
  (2, '2016-11-01', 'DD31',  1, '赤間一郎'),
  (3, '2016-11-02', 'DD28', 10, '岩瀬花子'),
  (4, '2016-11-03', 'DD28',  1, '内田二郎'),
  (5, '2016-11-04', 'XC01',  1, '岩瀬花子'),
  (6, '2016-11-05', 'FC96',  2, '赤間一郎');

insert into 住民 values
  ('VH17970','中野真衣','女','1948-11-14',NULL,NULL,NULL),
  ('TR97342','倉持政次','男','1928-05-16',NULL,NULL,NULL),
  ('GK63964','砂川守友','男','1928-04-09',NULL,NULL,'TC78601'),
  ('TC78601','砂川聡美','女','1934-03-06',NULL,NULL,'GK63964'),
  ('VI02116','藤崎恵利','女','1970-12-15',NULL,'VH17970',NULL),
  ('IS50201','中野洋二','男','1975-12-15',NULL,'VH17970',NULL),
  ('OE82563','倉持廣祐','男','1958-11-28','TR97342',NULL,NULL),
  ('GD16037','林史織','女','1965-05-08','GK63964','TC78601',NULL),
  ('YY43565','砂川優子','女','1961-11-14','GK63964','TC78601',NULL),
  ('CY55780','林晴菜','女','1995-10-07',NULL,'VI02116','GD92410'),
  ('CZ07412','藤崎徹子','女','1997-10-20',NULL,'VI02116',NULL),
  ('EL26259','中野登','男','2005-04-03','IS50201',NULL,NULL),
  ('GL78972','倉持優斗','男','1961-05-31','TR97342',NULL,'VL11647'),
  ('VL11647','倉持梨沙','女','1963-01-14','GK63964','TC78601','GL78972'),
  ('LL91484','倉持満','男','1988-02-28','GL78972','VL11647',NULL),
  ('GD92410','林金作','男','1995-09-07',NULL,'GD16037','CY55780');
  
