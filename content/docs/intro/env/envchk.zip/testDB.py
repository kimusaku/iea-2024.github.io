import MySQLdb
from MySQLdb.cursors import DictCursor 

db = MySQLdb.connect(
    host="localhost",
    user="root",
    passwd="",
    db="dbe2",
    charset='utf8'
)

c = db.cursor(DictCursor)
sql="""SELECT * FROM 家計簿"""
c.execute(sql)
for x in c:
    print(x)
print('---')
c = db.cursor(DictCursor)
c.execute('SELECT * FROM 家計簿 WHERE 費目 = %s', ('食費',))
for x in c:
    print(f"{x['日付']}の日付で，「{x['メモ']}」")
