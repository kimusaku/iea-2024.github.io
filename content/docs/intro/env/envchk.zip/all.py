from bottle import route, run, template
import MySQLdb
from MySQLdb.cursors import DictCursor 

def getFromDB(dateStr):
    db = MySQLdb.connect(
        host="localhost",
        user="root",
        passwd="",
        db="dbe2",
        charset='utf8'
    )
    c = db.cursor(DictCursor)
    sql="""SELECT * FROM 家計簿 where 日付 = %s"""
    c.execute(sql, (dateStr,))
    for x in c:
        return x['メモ']
    return None

@route('/check/<year>/<month>/<day>')
def check(year, month, day):
    dateStr = f'{year}-{month}-{day}'
    s = getFromDB(dateStr)
    if s:
        ret = template('家計簿の {{dateStr}} のメモの内容は「{{s}}」です．',
                       dateStr=dateStr, s=s)
    else:
        ret = template('家計簿には {{dateStr}} のデータがありません．',
                       dateStr=dateStr)
    return ret

run(host='localhost', port=8080, debug=True, reloader=True)
