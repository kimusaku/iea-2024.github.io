from flask import Flask, redirect, url_for, request, render_template, \
    flash, abort, make_response
import MySQLdb
from MySQLdb.cursors import DictCursor 

app = Flask(__name__)

def getFromDB(dateStr):
    db = MySQLdb.connect(
        host="localhost",
        user="root",
        passwd="",
        db="dbe2",
        charset='utf8'
    )
    c = db.cursor(DictCursor)
    sql="""SELECT * FROM 家計簿 where 日付 = %s"""
    c.execute(sql, (dateStr,))
    for x in c:
        return x['メモ']
    return None

@app.route('/check/<year>/<month>/<day>')
def check(year, month, day):
    dateStr = f'{year}-{month}-{day}'
    s = getFromDB(dateStr)
    ret = render_template('test1.html', dateStr=dateStr, s=s)
    return ret

app.run(host='localhost', port=18080, debug=True)
